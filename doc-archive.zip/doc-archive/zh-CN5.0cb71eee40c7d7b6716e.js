(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[367],{

/***/ 1193:
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(30);
            var content = __webpack_require__(1206);

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ 1205:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_mini_css_extract_plugin_dist_loader_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_sass_loader_dist_cjs_js_ref_5_3_node_modules_vue_loader_dist_index_js_ref_13_0_nav_vue_vue_type_style_index_0_id_6c694117_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1193);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_mini_css_extract_plugin_dist_loader_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_sass_loader_dist_cjs_js_ref_5_3_node_modules_vue_loader_dist_index_js_ref_13_0_nav_vue_vue_type_style_index_0_id_6c694117_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_cjs_js_node_modules_mini_css_extract_plugin_dist_loader_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_sass_loader_dist_cjs_js_ref_5_3_node_modules_vue_loader_dist_index_js_ref_13_0_nav_vue_vue_type_style_index_0_id_6c694117_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ 1206:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 684:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm-browser.prod.js
var vue_esm_browser_prod = __webpack_require__(0);

// CONCATENATED MODULE: ./website/assets/images/navbar_1.png
/* harmony default export */ var navbar_1 = (__webpack_require__.p + "static/navbar_1.7a3126b.png");
// CONCATENATED MODULE: ./website/assets/images/navbar_2.png
/* harmony default export */ var navbar_2 = (__webpack_require__.p + "static/navbar_2.c61d5c4.png");
// CONCATENATED MODULE: ./website/assets/images/navbar_3.png
/* harmony default export */ var navbar_3 = (__webpack_require__.p + "static/navbar_3.1933e8e.png");
// CONCATENATED MODULE: ./website/assets/images/navbar_0.png
/* harmony default export */ var navbar_0 = (__webpack_require__.p + "static/navbar_0.b226ca5.png");
// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/dist/templateLoader.js??ref--6!./node_modules/vue-loader/dist??ref--13-0!./website/pages/nav.vue?vue&type=template&id=6c694117&scoped=true






Object(vue_esm_browser_prod["pushScopeId"])("data-v-6c694117");

const _hoisted_1 = {
  class: "block"
};
const _hoisted_2 = {
  class: "block"
};
const _hoisted_3 = {
  class: "block"
};
const _hoisted_4 = {
  class: "block"
};
const _hoisted_5 = ["src"];

Object(vue_esm_browser_prod["popScopeId"])();

function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_el_col = Object(vue_esm_browser_prod["resolveComponent"])("el-col");

  const _component_el_row = Object(vue_esm_browser_prod["resolveComponent"])("el-row");

  return Object(vue_esm_browser_prod["openBlock"])(), Object(vue_esm_browser_prod["createElementBlock"])("div", null, [Object(vue_esm_browser_prod["createElementVNode"])("h2", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[1]), 1), Object(vue_esm_browser_prod["createElementVNode"])("div", _hoisted_1, [Object(vue_esm_browser_prod["createElementVNode"])("p", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[2]), 1)]), Object(vue_esm_browser_prod["createElementVNode"])("div", _hoisted_2, [Object(vue_esm_browser_prod["createElementVNode"])("h3", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[3]), 1), Object(vue_esm_browser_prod["createElementVNode"])("p", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[4]), 1)]), Object(vue_esm_browser_prod["createElementVNode"])("div", _hoisted_3, [Object(vue_esm_browser_prod["createElementVNode"])("h3", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[5]), 1), Object(vue_esm_browser_prod["createVNode"])(_component_el_row, {
    gutter: 20
  }, {
    default: Object(vue_esm_browser_prod["withCtx"])(() => [Object(vue_esm_browser_prod["createVNode"])(_component_el_col, {
      span: 9
    }, {
      default: Object(vue_esm_browser_prod["withCtx"])(() => [Object(vue_esm_browser_prod["createElementVNode"])("p", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[6]), 1)]),
      _: 1
    }), Object(vue_esm_browser_prod["createVNode"])(_component_el_col, {
      span: 15,
      class: "nav-demos"
    }, {
      default: Object(vue_esm_browser_prod["withCtx"])(() => [Object(vue_esm_browser_prod["createElementVNode"])("img", {
        src: navbar_1,
        alt: "{{ langConfig[7] }}",
        onClick: _cache[0] || (_cache[0] = $event => $options.enlarge(846, $event))
      }), Object(vue_esm_browser_prod["createElementVNode"])("h5", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[7]), 1), Object(vue_esm_browser_prod["createElementVNode"])("p", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[8]), 1), Object(vue_esm_browser_prod["createElementVNode"])("img", {
        src: navbar_2,
        alt: "{{ langConfig[9] }}",
        onClick: _cache[1] || (_cache[1] = $event => $options.enlarge(846, $event))
      }), Object(vue_esm_browser_prod["createElementVNode"])("h5", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[9]), 1), Object(vue_esm_browser_prod["createElementVNode"])("p", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[10]), 1), Object(vue_esm_browser_prod["createElementVNode"])("img", {
        src: navbar_3,
        alt: "{{ langConfig[11] }}",
        onClick: _cache[2] || (_cache[2] = $event => $options.enlarge(846, $event))
      }), Object(vue_esm_browser_prod["createElementVNode"])("h5", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[11]), 1), Object(vue_esm_browser_prod["createElementVNode"])("p", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[12]), 1)]),
      _: 1
    })]),
    _: 1
  })]), Object(vue_esm_browser_prod["createElementVNode"])("div", _hoisted_4, [Object(vue_esm_browser_prod["createElementVNode"])("h3", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[13]), 1), Object(vue_esm_browser_prod["createVNode"])(_component_el_row, null, {
    default: Object(vue_esm_browser_prod["withCtx"])(() => [Object(vue_esm_browser_prod["createVNode"])(_component_el_col, {
      span: 10
    }, {
      default: Object(vue_esm_browser_prod["withCtx"])(() => [Object(vue_esm_browser_prod["createElementVNode"])("p", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[14]), 1)]),
      _: 1
    }), Object(vue_esm_browser_prod["createVNode"])(_component_el_col, {
      span: 14,
      class: "nav-demos"
    }, {
      default: Object(vue_esm_browser_prod["withCtx"])(() => [Object(vue_esm_browser_prod["createElementVNode"])("img", {
        src: navbar_0,
        alt: "",
        onClick: _cache[3] || (_cache[3] = $event => $options.enlarge(846, $event))
      }), Object(vue_esm_browser_prod["createElementVNode"])("p", null, Object(vue_esm_browser_prod["toDisplayString"])($options.langConfig[15]), 1)]),
      _: 1
    })]),
    _: 1
  })]), Object(vue_esm_browser_prod["createVNode"])(vue_esm_browser_prod["Transition"], {
    name: "fade"
  }, {
    default: Object(vue_esm_browser_prod["withCtx"])(() => [Object(vue_esm_browser_prod["withDirectives"])(Object(vue_esm_browser_prod["createElementVNode"])("div", {
      class: "mask",
      onClick: _cache[4] || (_cache[4] = $event => $data.showDialog = false)
    }, null, 512), [[vue_esm_browser_prod["vShow"], $data.showDialog]])]),
    _: 1
  }), Object(vue_esm_browser_prod["createVNode"])(vue_esm_browser_prod["Transition"], {
    name: "zoom"
  }, {
    default: Object(vue_esm_browser_prod["withCtx"])(() => [Object(vue_esm_browser_prod["withDirectives"])(Object(vue_esm_browser_prod["createElementVNode"])("div", {
      class: "dialog-img",
      style: Object(vue_esm_browser_prod["normalizeStyle"])($data.imgWrapStyle),
      onClick: _cache[5] || (_cache[5] = $event => $data.showDialog = false)
    }, [Object(vue_esm_browser_prod["createElementVNode"])("div", {
      class: "imgWrap",
      style: Object(vue_esm_browser_prod["normalizeStyle"])($data.imgStyle)
    }, [Object(vue_esm_browser_prod["createElementVNode"])("img", {
      src: $data.imgUrl,
      alt: ""
    }, null, 8, _hoisted_5)], 4)], 4), [[vue_esm_browser_prod["vShow"], $data.showDialog]])]),
    _: 1
  })]);
}
// CONCATENATED MODULE: ./website/pages/nav.vue?vue&type=template&id=6c694117&scoped=true

// EXTERNAL MODULE: ./website/i18n/page.json
var page = __webpack_require__(1186);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/dist??ref--13-0!./website/pages/nav.vue?vue&type=script&lang=js

/* harmony default export */ var navvue_type_script_lang_js = ({
  data() {
    return {
      imgUrl: '',
      imgBound: {},
      showDialog: false,
      imgStyle: {},
      imgWrapStyle: {},
      lang: this.$route.meta.lang
    };
  },

  computed: {
    langConfig() {
      return page.filter(config => config.lang === this.lang)[0].pages.nav;
    }

  },
  watch: {
    showDialog(val) {
      document.body.style.overflow = val ? 'hidden' : '';
    }

  },
  methods: {
    enlarge(imgWidth, ev) {
      var imgNode = ev.target; // var bound = imgNode.getBoundingClientRect();

      var offset = {};
      var doc = document;
      offset.left = (doc.body.scrollWidth - imgWidth) / 2;
      offset.top = 100;
      this.imgUrl = imgNode.src;
      this.imgBound = imgNode.getBoundingClientRect();
      this.imgWrapStyle.transformOrigin = `${ev.clientX}px ${ev.clientY}px`; // this.imgStyle.transformOrigin = `${ev.clientX}px ${ev.clientY}px`;

      this.imgStyle.width = imgWidth + 'px';
      this.showDialog = true;
    }

  }
});
// CONCATENATED MODULE: ./website/pages/nav.vue?vue&type=script&lang=js
 
// EXTERNAL MODULE: ./website/pages/nav.vue?vue&type=style&index=0&id=6c694117&lang=scss&scoped=true
var navvue_type_style_index_0_id_6c694117_lang_scss_scoped_true = __webpack_require__(1205);

// CONCATENATED MODULE: ./website/pages/nav.vue





navvue_type_script_lang_js.render = render
navvue_type_script_lang_js.__scopeId = "data-v-6c694117"

/* harmony default export */ var nav = __webpack_exports__["default"] = (navvue_type_script_lang_js);

/***/ })

}]);